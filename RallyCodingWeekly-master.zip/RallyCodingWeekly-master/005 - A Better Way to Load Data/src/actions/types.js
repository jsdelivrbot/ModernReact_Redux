export const FETCH_PHOTOS = 'fetch_photos';

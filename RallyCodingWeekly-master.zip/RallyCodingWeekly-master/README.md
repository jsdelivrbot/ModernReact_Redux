#RallyCoding


Weekly videos on the Javascript and React Ecosystem.

Each separate folder contains the code for each weekly video.  You can run any individual project by running `npm install` then `npm start`, then navigate to `localhost:8080` in your browser.

### Videos

Check it out here: [RallyCoding.com](http://www.rallycoding.com)

### Tutorials

Interested in learning more about React and Redux?  Check out [Modern React with Redux](https://www.udemy.com/react-redux/?couponCode=rallycoding19) if you're just getting started, or [Advanced React and Redux](https://www.udemy.com/react-redux-tutorial/?couponCode=rallycoding19) if you're looking for some more challenging material.

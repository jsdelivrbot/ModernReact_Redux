import React, { Component } from 'react';

export default class User extends Component {
  render() {
    return (
      <div>
        <ul>
          <li>User #1</li>
          <li>User #2</li>
          <li>User #3</li>
        </ul>
      </div>
    );
  }
}

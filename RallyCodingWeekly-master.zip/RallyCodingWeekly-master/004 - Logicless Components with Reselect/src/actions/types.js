export const FETCH_POSTS = 'fetch_posts';
export const SELECT_POST = 'select_post';
export const DESELECT_POST = 'deslect_post';
